#!/bin/sh
cd client/
npm run-script build
cd ..
npm start
